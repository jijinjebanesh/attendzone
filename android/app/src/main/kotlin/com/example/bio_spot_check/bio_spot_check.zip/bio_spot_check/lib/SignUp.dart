import 'package:flutter/material.dart';
import 'TFD.dart';
import 'ApiC.dart';
TextEditingController Nusr = TextEditingController();
TextEditingController Npass = TextEditingController();
TextEditingController Nusrid = TextEditingController();

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  @override
  Widget build(BuildContext context) {
    var usridEM = "Enter New UserID" ;
    var usrEM = "Enter New UserName" ;
    var passEM = "Enter New Password" ;
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Up'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              height: 420,
              width: 300,
              padding: const EdgeInsets.all(40),
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
                color: Color(0xFF2413F0),
              ),
              child: Column(
                children: [
                  TFD(
                    hintText: "New UserID",
                    controller: Nusrid,
                  ),
                  const SizedBox(height: 25),
                  TFD(
                    hintText: "New Username",
                    controller: Nusr,
                  ),
                  const SizedBox(height: 30),
                  TFD(
                    hintText: "New Password",
                    controller: Npass,
                  ),
                  const SizedBox(height: 25),
                  ElevatedButton(
                    onPressed: () async {
                      if (Nusrid.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(usridEM)));
                      } else if (Nusr.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(usrEM)));
                      } else if (Npass.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(passEM)));
                      }
                      else {
                        String userIp= await Api().userIpAddress();
                        Verify verify = Verify();
                        verify.addUser(Nusrid.text, Nusr.text, Npass.text, userIp);

                      }
                    },
                    child: const Text(
                      "Sign Up",
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

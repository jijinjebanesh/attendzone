import 'dart:convert';
import 'package:http/http.dart' as http;

String userIp = '';

class Api {
  Future<String> userIpAddress() async {
    try{
      final response =
      await http.get(Uri.parse('https://api64.ipify.org?format=json'));
      if (response.statusCode == 200) {
        final ipAddress = json.decode(response.body)["ip"];
        userIp = ipAddress;
        return userIp;
      }
      else{
        return "";
      }
    }
    catch(e){
      return e.toString();
    }
  }
}

class Verify {
  Map<String, List<String>> Users = {
    'uid':  ['123', '3123', '54734'],
    'name': ['jijin', 'dodo', 'heha'],
    'pass': ["12", "32", "45"],
    'ip': ['42.106.176.184', '42.106.176.184', '7457.314.674.44']
  };

  bool verify(String userid, String username, String pass, String userIp) {
    List<Map<String, dynamic>> usrList = [];
    for (var i = 0; i < Users['name']!.length; i++) {
      Map<String, dynamic> usr = {
        'uid': Users['uid']![i],
        'name': Users['name']![i],
        'pass': Users['pass']![i],
        'ip': Users['ip']![i]
      };
      usrList.add(usr);
    }

    int? foundIndex;
    for (var i = 0; i < usrList.length; i++) {
      if (usrList[i]['uid'] == userid) {
        foundIndex = i;
        break;
      }
    }
    if (foundIndex != null) {
      if (usrList[foundIndex]['pass'] == pass) {
        if (usrList[foundIndex]['ip'] == userIp) {
          return true;
        }
      }
    }
    return false;
  }

  void addUser(String userid, String username, String pass, String userip) {
    Users['uid']!.add(userid);
    Users['name']!.add(username);
    Users['pass']!.add(pass);
    Users['ip']!.add(userip);

  }
}

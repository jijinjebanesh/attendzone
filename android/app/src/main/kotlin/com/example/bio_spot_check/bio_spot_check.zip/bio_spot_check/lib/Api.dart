import 'dart:convert';
import 'package:http/http.dart' as http;
String userIp = '';
class Api {
  Future<String> userIpAddress() async {
    try{
      final response =
      await http.get(Uri.parse('https://api64.ipify.org?format=json'));
      if (response.statusCode == 200) {
        final ipAddress = json.decode(response.body)["ip"];

        userIp = ipAddress;
        return userIp;
      }
      else{
        return "";
      }
    }
    catch(e){
      return e.toString();
    }

  }
}
//void fetchData() async {
  //var url = Uri.parse('http://localhost:20200930/Users');
  //var response = await http.get(url);
  //if (response.statusCode == 200) {
    //print('Data fetched successfully');
  //} else {
   // print('Failed to load data');
  //}
//}

final  Map<String, String> user1 = {"userid":'100', "username":'jijin', "password":'123',"ip":"42.106.176.184"}; //202.53.4.0

class Verify{
    bool verify(userid,username,pass,userIp){
      if(user1["userid"]==userid){
        if(user1["password"]==pass){
          if(user1["ip"]==userIp){
            return true;
          }
          else{
            return false;
          }
        }else {
          return false;
        }
      }
      else{
            return false;
      }
  }

}

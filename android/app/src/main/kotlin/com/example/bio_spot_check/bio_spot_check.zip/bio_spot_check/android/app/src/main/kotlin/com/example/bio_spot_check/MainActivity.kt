package com.example.bio_spot_check

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

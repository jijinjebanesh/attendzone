import 'package:flutter/material.dart';
import 'package:bio_spot_check/TFD.dart';
import 'Api.dart';
import 'Home.dart';
import 'SignUp.dart';
 TextEditingController usr = TextEditingController();
 TextEditingController pass=TextEditingController();
 TextEditingController usrid = TextEditingController();

void main () => runApp(const FirstPage());
class FirstPage  extends StatefulWidget {
  const FirstPage({super.key});

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  @override
  Widget build(BuildContext context) {


    return  const MaterialApp(
      debugShowCheckedModeBanner: false,
       home: Home(),
    );
  }
}
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    var usridEM = "Enter UserID" ;
    var usrEM = "Enter UserName" ;
    var passEM = "Enter Password" ;
    return Scaffold(
      backgroundColor: Colors.purple,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              height:420,
              width: 300,
              padding: const EdgeInsets.all(40),
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
                color: Colors.purple,
              ),
              child: Column(
                children: [
                  TFD(hintText: "UserID",
                    controller: usrid,),
                  const SizedBox(height: 25,),
                  TFD(hintText: "Username",
                      controller:usr),
                  const SizedBox(height: 30,),
                  TFD(hintText: "Password",
                    controller: pass,),
                  const SizedBox(height: 25,),
                  FilledButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.black),
                    ),
                    onPressed: () async{
                      if(usrid.text.isEmpty){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
                            usridEM
                        ),));
                      }
                      else if(usr.text.isEmpty){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
                            usrEM
                        ),));
                      }
                      else if(pass.text.isEmpty){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
                            passEM
                        ),));
                      }
                      else  {
                      String userIp= await Api().userIpAddress();
                     // fetchData();
                      print(userIp);
                     bool login=  Verify().verify(usrid.text,usr.text,pass.text,userIp);
                     if(login == true){
                       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text(
                           "Login Successful"),
                       duration: Duration(seconds: 2),));
                       Navigator.push(
                         context,
                         MaterialPageRoute(builder: (context) => const home()),
                       );
                     }
                     else{ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text(
                         "Login Faild"
                     ),));

                     }
                      }
                    },
                    child: const Text("Login",
                      style: TextStyle(
                        fontSize:  20 ,
                      ),),
                  ),
                  const SizedBox(height: 10,),
                  const Text(""),
                ],
              ),
            ),
              // ElevatedButton(
              //   onPressed: () {
              //     Navigator.push(context, MaterialPageRoute(builder: (context) => const Signup()));
              //   },
              //   child: const Text(
              //     "Sign up",
              //     style: TextStyle(
              //       fontSize: 20,
              //     ),|
              //   ),
              // )

          ],

        ),
      ),
    );
  }
}

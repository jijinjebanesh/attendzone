import 'package:flutter/material.dart';

class Vcred extends StatelessWidget {
  final List<String> Vuserid = ['a1', 'b1', 'c1'];
  final List<String> Vuser = ['a', 'b', 'c'];
  final List<int> Vpass = [1, 2, 3];
  final List<String> Vip = ['1234', '21342', '543523'];
  List users=[[],['a', 'b', 'c'],[]];

  Vcred({super.key});


  Map<int, Map<String, dynamic>> VCred() {

    return Vuser.asMap().map((index, value) {
      return MapEntry(index, {'Vuser': value, 'Vpass': Vpass[index], 'Vip': Vip[index]});
    });
  }

  @override
  Widget build(BuildContext context)  {
    // You need to return a widget here.
    return Container();
  }
}
